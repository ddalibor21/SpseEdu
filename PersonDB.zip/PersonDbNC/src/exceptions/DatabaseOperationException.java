package exceptions;

public class DatabaseOperationException extends RuntimeException {
	private static final long serialVersionUID = -5480179764716488473L;

	public DatabaseOperationException(String message, Throwable cause) {
		super(message, cause);
	}

}
