package exceptions;

public class InvalidIdentityException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InvalidIdentityException(long id) {
		super(String.format("ID number %l is invalid", id));
	}

	public InvalidIdentityException(String message) {
		super(message);
	}

}
