package model;

import exceptions.InvalidIdentityException;

/**
 * Stores unique ID for database operations
 * 
 * @author dadamcik
 */
public abstract class IdentityNumber {

	private long id;

	public IdentityNumber() {
		this.id = 0;
	}

	public final long getId() {
		return id;
	}

	public final boolean idEquals(long id) {
		return this.id == id;
	}

	public final void setId(long id) {
		if (id < 1)
			throw new InvalidIdentityException(id);

		this.id = id;
	}

}
