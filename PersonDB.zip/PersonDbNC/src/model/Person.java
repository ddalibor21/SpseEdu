package model;

/**
 * Osoba.. jednoducha trieda ktora obsahuje meno, priezvisko, vek
 * 
 * @author dadamcik
 *
 */
public class Person extends IdentityNumber {

	private String name;
	private String surname;
	private int age;

	public Person() {
		super();
		this.name = "";
		this.surname = "";
		this.age = 0;
	}

	public Person(String name, String surname, int age) {
		this(); // zavolame nas defaultny konstruktor
		setName(name);
		setSurname(surname);
		setAge(age);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return String.format("Person: %s, %s (%d)", surname, name, age);
	}

}
