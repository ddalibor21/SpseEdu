package run;

/**
 * Spustenie aplikacie
 * 
 * @author dadamcik
 *
 */
public class Runner {

	public static void main(String[] args) {
		// GOOGLE: java 8 try with resources
		try (App app = new App(); /* vytvorime novy objekt aplikacie */ ) {
			app.run(); // spustime hlavnu ponuku aplikacie
		} catch (Exception e) {
			System.err.printf("Pocas behu aplikacie doslo k neocakavanej chybe: %s | %s\r\n",
					e.getClass().getSimpleName(), e.getMessage());
		}
	}

}
