package run;

import java.util.InputMismatchException;
import java.util.Scanner;

import model.Person;
import service.PersonService;
import service.impl.PersonSvcDatabase;
import service.impl.PersonSvcFile;

/**
 * Hlavna cast programu
 * 
 * @author dadamcik
 *
 */
public class App implements AutoCloseable {

	private Scanner keyboard;
	PersonService svc;

	public App() {
		// instancia servisu
		this.svc = new PersonSvcFile();

		// vytvorime scanner z "klavesnice"
		this.keyboard = new Scanner(System.in);
	}

	/**
	 * hlavny cyklus aplikacie. zobrazi menu a cita z klavesnice co chceme spravit
	 */
	public void run() {

		int choice = 0;

		do {
			// vypiseme menu
			System.out.println("0: Exit");
			System.out.println("1: Print list of persons");
			System.out.println("2: Add person");
			System.out.println("3: Remove person");
			System.out.println("4: Remove ALL");

			// citame moznost
			choice = readInt();

			// spracujeme vyber
			processChoice(choice);

			// opakujeme kym nezadame moznost nula - exit
		} while (choice != 0);

	}

	/**
	 * citanie cisla z klavesnice, predchadza zadavaniu zlych cisel (napriklad textu
	 * :-D)
	 */
	private int readInt() {
		Integer i = null;
		do {
			try {
				i = keyboard.nextInt();
			} catch (InputMismatchException e) {
				i = null;
			}

			// stlacili sme enter za cislom, treba to osetrit...
			if (keyboard.hasNextLine())
				keyboard.nextLine();

		} while (i == null);
		return i.intValue();
	}

	/**
	 * Spracuje zadanu moznost z menu
	 * 
	 * @param choice
	 *            {@link Integer} cislo, ktore sme zadali v menu
	 */
	private void processChoice(int choice) {
		switch (choice) {
		case 0:
			System.out.println("Bye bye..");
			break;
		case 1: // vytlacit zoznam osob
			printPersons();
			break;
		case 2: // pridat osobu
			addPerson();
			break;
		case 3: // zmazat osobu
			removePerson();
			break;
		case 4:
			svc.removeAll();
			; // zmazeme cely zoznam osob
			break;
		default: // ak sme zadali blbost, tak to povieme uzivatelovi, nech sa
					// cuduje
			System.out.printf("What is %d???, try again\r\n", choice);
			break;
		}
	}

	private void printPersons() {
		final String format = "%3s | \t%10s\t%10s\t%s\r\n";
		System.out.printf(format, "ID", "Name", "Suname", "Age");// vypisem
																	// hlavicku
		System.out.println("---------------------------------------------------------------------");

		for (Person p : svc.listPersons()) {
			// vypiseme riadok s osobou
			System.out.printf(format, p.getId(), p.getName(), p.getSurname(), p.getAge());
		}
	}

	/**
	 * Nacita z klavesnice udaje o novej osobe a prida ju do zoznamu osob.
	 */
	private void addPerson() {
		// nacitame vsetko z klavesnice
		System.out.println("Add person ----------------------");
		System.out.print("Name: ");
		String name = keyboard.nextLine();
		System.out.print("Surname: ");
		String surname = keyboard.nextLine();
		System.out.print("Age: ");
		int age = readInt();

		// vytvorime objekt person so zadanymi parametrami
		Person per = new Person(name, surname, age);
		// pridame osobu do zoznamu
		svc.addPerson(per);
	}

	/**
	 * Vyhodi osobu zo zoznamu. Nacita z klavesnice ID osoby, a ak existuje tak ju
	 * odstrani
	 */
	private void removePerson() {
		System.out.print("Enter ID of person to be deleted");
		int id = readInt();
		Person p = svc.getPerson(id);

		if (p == null) {
			System.out.printf("Invalid person ID: %d\r\n", id);
			return; // vyskocime z metody a vratime sa tam kde nas zavolali
		}
		// ak by sme dali zle ID do remove, vyskoci
		// exception, ale my to uz mame osetrene

		System.out.printf("Removing person %s...\r\n", p);
		svc.removePerson(p);
	}

	@Override
	public void close() throws Exception {
		svc.close();
	}

}
