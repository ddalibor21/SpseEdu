package service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import model.Person;
import service.PersonService;

/**
 * PersonDatabase into file
 * 
 * @author dadamcik
 *
 */
public class PersonSvcFile implements PersonService {

	private List<Person> persons;
	// subor v ktorom su ulozene udaje
	private static File MY_FILE = new File("data.txt");

	public PersonSvcFile() {
		persons = new ArrayList<>();
		load();
	}

	@Override
	public boolean addPerson(Person p) {
		if (persons.add(p)) {
			save();
			return true;
		}
		return false;
	}

	@Override
	public Person getPerson(long id) {
		for(Person p: persons) {
			if(p!=null && p.idEquals(id))
				return p;
		}
		return null;
	}
	
	@Override
	public boolean removePerson(Person p) {
		if (persons.remove(p)) {
			save();
			return true;
		}
		return false;
	}

	@Override
	public List<Person> listPersons() {
		for (int i = 0; i < persons.size(); i++)
			persons.get(i).setId(i+1);
		return Collections.unmodifiableList(persons);
	}

	@Override
	public void removeAll() {
		persons.clear();
		save();
	}

	@Override
	public void close() {
		save();
	}

	/**
	 * Nacitanie udajov zo suboru. Udaje v subore su ulozene v citatelnom formate.
	 * Exituje aj efektivnejsie ukladanie objektov do suboru (binarne) ale pre tento
	 * priklad je to lepsie / aby ste videli co je v subore.
	 */
	public void load() {
		// prva moznost ako zistit ci subor neexistuje
		if (!MY_FILE.exists()) {
			System.out.println(">> Data file not found. #1");
			return;
		}

		try (Scanner load = new Scanner(MY_FILE);) {
			// vytvorime si novy list. Budeme ho pouzivat ako medzipamat pri
			// nacitani suboru
			// mohli by sme pouzit aj string[], ale s tym by sme mali viac roboty
			List<String> cache = new ArrayList<>();
			// spytame sa ci je v subore dalsi riadok, ak je tak to nejako
			// spracujeme :)
			while (load.hasNextLine()) {
				cache.add(load.nextLine()); // nacitame riadok zo suboru,
											// ulozime do cache.

				// ak mame ulozene prave tri riadky, je cas premenit text na
				// objekt person
				if (cache.size() == 3) {
					// zmenime riadky na objekt.. pozrite ako (CTRL + kliknite
					// na loadPerson - eclipse)
					Person person = loadPerson(cache);
					// vlozime do zoznamu osob
					persons.add(person);

					// vymazeme vsetko zo zoznamu
					cache.clear();
				}

				// ak by sme nekontrolovali, ci je velkost cache prave 3, tak pri
				// vytvarani objektu person by
				// mohlo dojst k chybe. Ak stratime jeden riadok niekde na
				// zaciatku suboru = pruser.
				// Ak na konci, tak sa nestane nic, len nevytvorime objekt person.
			}

		} catch (FileNotFoundException e) { // druha moznost, ze chytime vynimku
											// a zistime ze subor neexistuje
			// sem by sme sa teoreticky dostat nemali, lebo to mame osetrene
			System.out.println(">> Data file not found. #2");
		}

	}

	/**
	 * Zmeni list stringov na objekt. Toto by sa dalo urobit aj ako parametricky
	 * konstruktor v triede Person.<br>
	 * 
	 * @param cache
	 *            {@link List} of {@link String} riadky nacitane zo suboru
	 * @return {@link Person} novy objekt Person s nacitanymi udajmi z listu
	 */
	private Person loadPerson(List<String> cache) {
		// Vytvorime objekt person
		Person person = new Person();
		// nastavime si vlastnosti objektu, podla poradia ako sme zapisali do
		// suboru
		person.setName(cache.get(0));
		person.setSurname(cache.get(1));

		// ajaj, pri veku mame problem. Person chce v metode setAge(..) integer,
		// my mame string. ideme carovat (do some magic).
		int age = Integer.parseInt(cache.get(2)); // tu moze vzniknut vynimka
													// NumberFormatException, ak
													// strcime namiesto cisla
													// znak, napr: 01a
		person.setAge(age);

		// vratime objekt s vlastnostami
		return person;
	}

	/**
	 * Ulozenie udajov do suboru
	 */
	public void save() {
		PrintWriter write = null;
		// klasicky sposob pouzitia try - try without resources - kopa kodu
		// naviac.... :-/
		try {
			write = new PrintWriter(MY_FILE);

			// GOOGLE: Java foreach / iteracia zoznamom osob
			for (Person person : persons) {
				// ulozime osobu do suboru
				savePerson(person, write);
			}

		} catch (FileNotFoundException e) {
			// vynimka ze nexistuje subor, vypiseme jej obsah.... ze co sa stalo
			// (kopa citania same pismenka a cisla)
			e.printStackTrace();
		} finally {
			if (write != null) { // zistime ci sme otvorili subor na zapis
				write.close(); // uzavrieme subor
			}
		}

	}

	/**
	 * Ulozenie osoby do ""suboru"".
	 * 
	 * @param person
	 *            {@link Person} osoba ktoru chceme ulozit
	 * @param write
	 *            {@link PrintWriter} miesto kam to chceme zapisat
	 */
	private void savePerson(Person person, PrintWriter write) {
		write.println(person.getName());
		write.println(person.getSurname());
		write.println(person.getAge());
	}

}
