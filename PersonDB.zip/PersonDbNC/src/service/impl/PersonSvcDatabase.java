package service.impl;

import java.sql.SQLException;
import java.util.List;

import model.Person;
import service.PersonService;

/**
 * PersonDatabase into file
 * 
 * @author dadamcik
 *
 */
public class PersonSvcDatabase implements PersonService {



	public PersonSvcDatabase() {
		// initialize databaze coonnection
	}

	@Override
	public void close() throws SQLException {
		//close databaze connection
	}

	@Override
	public boolean addPerson(Person p) {
		throw new UnsupportedOperationException("Needs implementation");
	}

	@Override
	public Person getPerson(long id) {
		throw new UnsupportedOperationException("Needs implementation");
	}

	@Override
	public boolean removePerson(Person p) {
		throw new UnsupportedOperationException("Needs implementation");
	}

	@Override
	public List<Person> listPersons() {
		throw new UnsupportedOperationException("Needs implementation");
	}

	@Override
	public void removeAll() {
		throw new UnsupportedOperationException("Needs implementation");
	}

}
