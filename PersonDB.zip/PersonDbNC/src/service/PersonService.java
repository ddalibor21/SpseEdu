package service;

import java.util.List;

import model.Person;

public interface PersonService extends AutoCloseable {
	/**
	 * Prida novu osobu do zoznamu
	 * 
	 * @param p
	 *            {@link Person} osoba na pridanie
	 * @return {@link Boolean} <code>true</code> osobu sa podarilo pridat inac
	 *         <code>false</code>
	 */
	boolean addPerson(Person p);

	/**
	 * Odstrani existujucu osobu zo zoanmu
	 * 
	 * @param p
	 *            {@link Person} osoba na odstranenie
	 * @return {@link Boolean} <code>true</code> osobu sa podarilo odstranit inac
	 *         <code>false</code>
	 */
	boolean removePerson(Person p);

	/**
	 * Zoznam vstkych osob
	 * 
	 * @return {@link List} s {@link Person}
	 */
	List<Person> listPersons();

	/**
	 * Odstrani vsetky osoby
	 */
	void removeAll();

	/**
	 * Ziska osobu na zaklade jej unikatneho ID
	 * 
	 * @param id
	 *            {@link Long} id osoby
	 * @return {@link Person} ak ju najde tak vrati osobu, inak <code>null</code>
	 */
	Person getPerson(long id);
}
